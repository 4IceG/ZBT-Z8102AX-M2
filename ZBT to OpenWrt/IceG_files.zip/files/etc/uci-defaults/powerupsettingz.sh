#!/bin/sh

uci set network.globals.packet_steering='1'
uci set firewall.@defaults[0].flow_offloading='1'
uci set firewall.@defaults[0].flow_offloading_hw='1'
#uci commit firewall
uci commit
#service firewall restart
/etc/init.d/firewall restart

rm -rf /tmp/luci-indexcache  2>&1 &
rm -rf /tmp/luci-modulecache/  2>&1 &
exit 0
